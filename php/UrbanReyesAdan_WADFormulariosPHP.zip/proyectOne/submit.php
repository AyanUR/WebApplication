<?php
	if($_POST['enter']){
		echo "button enter was pushed";
	}
?>
