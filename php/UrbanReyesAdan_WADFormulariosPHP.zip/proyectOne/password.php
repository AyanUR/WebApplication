<?php
	if($_POST['send']){
		$password=$_POST['password'];
		echo "password is: $password";
	}
?>
