<?php
	if($_POST['sendAge']){
		$age=$_REQUEST['age'];
		print ("the age is $age");
	}
?>
