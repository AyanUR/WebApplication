<?php
	if($_POST['send']){
		$coment=$_POST['coment'];
		echo "$coment";
	}
?>
