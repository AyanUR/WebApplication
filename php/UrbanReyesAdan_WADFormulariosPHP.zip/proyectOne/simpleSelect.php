<?php
	if($_POST['send']){
		$color=$_POST['color'];
		echo "color selected: $color";
	}
?>
