<?php
	if($_POST['send']){
		$file=$_POST['file'];
		echo "file=$file";
	}
?>
