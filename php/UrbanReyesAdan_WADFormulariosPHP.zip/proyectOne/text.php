<?php
	if($_REQUEST['search']){
		$string=$_REQUEST['string'];
		print ($string);
	}
?>
