<?php
	if($_REQUEST['enter']){
		$sexo=$_REQUEST['sexo'];
		print($sexo);
	}
?>
